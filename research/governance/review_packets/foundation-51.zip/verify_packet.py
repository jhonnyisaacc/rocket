import hashlib,json
from pathlib import Path
p=Path(__file__).parent
m=json.loads((p/"source_manifest.json").read_text())
for f in m["files"]:
 assert hashlib.sha256((p/f["path"]).read_bytes()).hexdigest()==f["sha256"], f["path"]
print("VERIFIED",len(m["files"]),"pinned files; no acceptance or scoring permission")
