#!/usr/bin/env python3
# ============================================================
# placebo_bootstrap_v3.py
# "Detection-validated" placebo: apply the same cohort-detection
# algorithm from analyze_sniper_cohorts.py (co-occurrence >=3,
# union-find, cohort size 2..12) to the activity-matched placebo
# wallet sample. Treated = mints touched by any of the detected
# placebo cohorts (>=2 wallets in first-10, from a detected pair).
# This tests whether the paper's reported n_placebo_treated ~173
# comes from also running the detection step on placebos.
# ============================================================

import json, os, time, bisect
from collections import defaultdict, Counter
from datetime import datetime, timezone
import numpy as np

BUYERS_PATH  = '<data-path>/pumpfun_buyers.jsonl.stale_2026-06-29'
COHORTS_PATH = '<data-path>/sniper_cohorts.jsonl'
OUT_JSON     = '<out-path>/placebo_stability_v3_detected.json'
OUT_TXT      = '<out-path>/placebo_stability_v3_detected.txt'

FIRST_N          = 10
WINDOW_30M       = 30 * 60
CONTROL_RATIO    = 3
N_SEEDS          = 100
MATCH_TOLERANCE  = 0.25
MIN_LAUNCHES     = 3        # same as analyze_sniper_cohorts.py
MAX_COHORT_SIZE  = 12
REAL_LIFT        = 132.3
REAL_CI_HI       = 137.4
REAL_N_TREATED   = 5411

W_START = int(datetime(2026, 6, 12, tzinfo=timezone.utc).timestamp())
W_END   = int(datetime(2026, 6, 26, tzinfo=timezone.utc).timestamp())

def log(msg): print(f'[{time.strftime("%H:%M:%S")}] {msg}', flush=True)

log('loading cohorts')
cohort_wallets_set = set()
cohort_sizes = []
with open(COHORTS_PATH) as f:
    for line in f:
        r = json.loads(line); ws = r.get('wallets', [])
        cohort_wallets_set.update(ws); cohort_sizes.append(len(ws))

log('loading buyers')
per_mint = defaultdict(list); t0=time.time()
with open(BUYERS_PATH) as f:
    for line in f:
        try: r=json.loads(line)
        except: continue
        bt=r.get('blockTime')
        if bt is None or bt<W_START or bt>W_END: continue
        m=r.get('mint'); w=r.get('wallet')
        if not m or not w: continue
        per_mint[m].append((w, r.get('buyer_rank') or 9999, bt))
log(f'  {len(per_mint)} mints in {time.time()-t0:.1f}s')

mint_first10 = {}; mint_bc30 = {}
for m, buys in per_mint.items():
    buys.sort(key=lambda x:(x[1],x[2]))
    seen=set(); f10=[]
    for w,_,_ in buys:
        if w in seen: continue
        seen.add(w); f10.append(w)
        if len(f10)>=FIRST_N: break
    mint_first10[m]=frozenset(f10)
    t_first=min(bt for _,_,bt in buys)
    uniq30={w for w,_,bt in buys if bt<=t_first+WINDOW_30M}
    mint_bc30[m]=len(uniq30)
del per_mint

# wallet -> mints (first-10 index)
wallet_activity = Counter()
wallet_to_mints = defaultdict(list)
for m, f10 in mint_first10.items():
    for w in f10:
        wallet_activity[w] += 1
        wallet_to_mints[w].append(m)

cohort_activity = {w: wallet_activity[w] for w in cohort_wallets_set if w in wallet_activity}
noncohort_by_activity = defaultdict(list)
for w, a in wallet_activity.items():
    if w in cohort_wallets_set: continue
    noncohort_by_activity[a].append(w)
noncohort_act_sorted = sorted(noncohort_by_activity.keys())
noncohort_arrays = {a: np.array(ws) for a, ws in noncohort_by_activity.items()}

def match_placebo(rng, tol=MATCH_TOLERANCE):
    out = []
    for w, act in cohort_activity.items():
        lo = max(1, int(np.floor(act*(1-tol))))
        hi = max(lo, int(np.ceil(act*(1+tol))))
        pool = [noncohort_arrays[a] for a in range(lo,hi+1) if a in noncohort_arrays]
        if pool:
            cand = np.concatenate(pool) if len(pool)>1 else pool[0]
        else:
            i = bisect.bisect_left(noncohort_act_sorted, act)
            best,bd = None, 10**9
            for j in (i-1,i,i+1):
                if 0<=j<len(noncohort_act_sorted):
                    d=abs(noncohort_act_sorted[j]-act)
                    if d<bd: bd,best = d, noncohort_act_sorted[j]
            cand = noncohort_arrays[best]
        out.append(cand[rng.integers(0, len(cand))])
    return out

# Union-Find
class UF:
    def __init__(self): self.p = {}
    def find(self,x):
        self.p.setdefault(x,x)
        while self.p[x]!=x:
            self.p[x]=self.p[self.p[x]]; x=self.p[x]
        return x
    def union(self,a,b):
        ra,rb=self.find(a),self.find(b)
        if ra!=rb: self.p[ra]=rb

def detect_placebo_cohorts(placebo_set):
    """Apply MIN_LAUNCHES threshold on pair co-occurrence, union-find into components."""
    # Count pair co-occurrence in first-10, restricted to placebo wallets
    pair_count = Counter()
    for m, f10 in mint_first10.items():
        # placebo wallets in this mint's first-10
        pcs = [w for w in f10 if w in placebo_set]
        if len(pcs) < 2: continue
        pcs.sort()
        for i, a in enumerate(pcs):
            for b in pcs[i+1:]:
                pair_count[(a,b)] += 1
    # Union-find on qualifying pairs
    uf = UF()
    for (a,b), n in pair_count.items():
        if n >= MIN_LAUNCHES:
            uf.union(a,b)
    groups = defaultdict(set)
    for w in list(uf.p):
        groups[uf.find(w)].add(w)
    return [sorted(g) for g in groups.values() if 2 <= len(g) <= MAX_COHORT_SIZE]

def cohorts_touched_mints(cohorts):
    touched = set()
    for c in cohorts:
        cs = set(c)
        cand = set()
        for w in cs: cand.update(wallet_to_mints.get(w, ()))
        for m in cand:
            f10 = mint_first10[m]
            cnt = 0
            for w in cs:
                if w in f10:
                    cnt += 1
                    if cnt >= 2: break
            if cnt >= 2:
                touched.add(m)
    return touched

log(f'starting {N_SEEDS} iterations (DETECTED definition)')
results = []
mint_list_np = np.array(list(mint_first10.keys()))

for seed in range(N_SEEDS):
    t_seed = time.time()
    rng = np.random.default_rng(seed)
    placebo = match_placebo(rng)
    placebo_set = set(placebo)

    detected = detect_placebo_cohorts(placebo_set)
    touched = cohorts_touched_mints(detected)
    n_treated = len(touched)

    if n_treated == 0:
        results.append({'seed': seed, 'n_detected_cohorts': len(detected),
                        'n_treated': 0, 'n_control': 0,
                        'mean_t':0.0, 'mean_c':0.0, 'lift_pct': float('nan'),
                        'n_placebo_unique': len(placebo_set)})
        if seed % 5 == 0: log(f'  seed {seed:3d}: 0 detected/treated')
        continue

    untouched = np.array([m for m in mint_list_np if m not in touched])
    n_control = min(CONTROL_RATIO * n_treated, len(untouched))
    control_pick = rng.choice(len(untouched), size=n_control, replace=False)
    control_mints = untouched[control_pick]

    treated_bc = np.array([mint_bc30[m] for m in touched])
    control_bc = np.array([mint_bc30[m] for m in control_mints])
    mean_t = float(treated_bc.mean())
    mean_c = float(control_bc.mean())
    lift = (mean_t/mean_c - 1.0)*100.0 if mean_c > 0 else float('nan')

    results.append({'seed': seed, 'n_detected_cohorts': len(detected),
                    'n_treated': int(n_treated), 'n_control': int(len(control_mints)),
                    'mean_t': mean_t, 'mean_c': mean_c, 'lift_pct': lift,
                    'n_placebo_unique': len(placebo_set)})
    if seed % 5 == 0 or seed == N_SEEDS - 1:
        log(f'  seed {seed:3d}: n_detected={len(detected):3d}, n_treated={n_treated:4d}, lift={lift:+7.1f}%, t={time.time()-t_seed:.1f}s')

lifts    = np.array([r['lift_pct']  for r in results if not np.isnan(r['lift_pct'])])
n_treats = np.array([r['n_treated'] for r in results])
n_dets   = np.array([r['n_detected_cohorts'] for r in results])
n_uniq   = np.array([r['n_placebo_unique'] for r in results])

summary = {
    'definition': 'DETECTED: apply MIN_LAUNCHES>=3 union-find to placebo pool, then compute touched',
    'n_seeds_completed': len(results),
    'n_seeds_valid_lift': int(len(lifts)),
    'match_tolerance_pct': MATCH_TOLERANCE*100,
    'real_cohort_lift_pct': REAL_LIFT,
    'real_cohort_ci_hi': REAL_CI_HI,
    'real_cohort_n_treated': REAL_N_TREATED,
    'window_utc': ['2026-06-12','2026-06-26'],
    'n_detected_cohorts': {'median': int(np.median(n_dets)), 'min': int(n_dets.min()),
                           'max': int(n_dets.max()), 'mean': float(n_dets.mean())},
    'n_treated': {'median': int(np.median(n_treats)), 'min': int(n_treats.min()),
                  'max': int(n_treats.max()), 'mean': float(n_treats.mean())},
    'n_placebo_unique': {'median': int(np.median(n_uniq)), 'min': int(n_uniq.min()),
                         'max': int(n_uniq.max())},
    'lift_pct': ({'median': float(np.median(lifts)),
                  'p5': float(np.percentile(lifts,5)),
                  'p95': float(np.percentile(lifts,95)),
                  'min': float(lifts.min()), 'max': float(lifts.max()),
                  'mean': float(lifts.mean()),
                  'std': float(lifts.std(ddof=1)) if len(lifts)>1 else 0.0}
                 if len(lifts)>0 else None),
    'fraction_lift_gt_ci_hi': float(np.mean(lifts > REAL_CI_HI)) if len(lifts)>0 else None,
    'fraction_lift_gt_real_point': float(np.mean(lifts > REAL_LIFT)) if len(lifts)>0 else None,
    'results_per_seed': results,
}

with open(OUT_JSON,'w') as f: json.dump(summary, f, indent=2)

lines = ['='*68,
         'Paper 7 activity-matched placebo — 100-seed stability test',
         'DEFINITION: DETECTED (union-find with min co-occurrence 3 on placebo pool)',
         '='*68,
         'window (UTC): 2026-06-12 .. 2026-06-26',
         f'match tolerance: +/- {int(MATCH_TOLERANCE*100)}%',
         f'seeds completed: {summary["n_seeds_completed"]}   valid lift: {summary["n_seeds_valid_lift"]}',
         '',
         f'REAL cohort ref: lift=+{REAL_LIFT}%; 95% CI upper={REAL_CI_HI}%; n_treated={REAL_N_TREATED}',
         '',
         f'placebo unique wallets/seed:  median={summary["n_placebo_unique"]["median"]} range=[{summary["n_placebo_unique"]["min"]}..{summary["n_placebo_unique"]["max"]}]',
         f'detected placebo cohorts/seed: median={summary["n_detected_cohorts"]["median"]}, mean={summary["n_detected_cohorts"]["mean"]:.1f}, range=[{summary["n_detected_cohorts"]["min"]}..{summary["n_detected_cohorts"]["max"]}]',
         '',
         f'n_treated: median={summary["n_treated"]["median"]}  min={summary["n_treated"]["min"]}  max={summary["n_treated"]["max"]}  mean={summary["n_treated"]["mean"]:.1f}',
         '']
if summary['lift_pct']:
    lp = summary['lift_pct']
    lines.append(f'lift (%): median={lp["median"]:+.1f}  p5={lp["p5"]:+.1f}  p95={lp["p95"]:+.1f}  min={lp["min"]:+.1f}  max={lp["max"]:+.1f}  mean={lp["mean"]:+.1f}  std={lp["std"]:.1f}')
    lines.append('')
    lines.append(f'Fraction seeds with placebo_lift > {REAL_CI_HI}% (real CI hi): {summary["fraction_lift_gt_ci_hi"]*100:.1f}% ({int(round(summary["fraction_lift_gt_ci_hi"]*summary["n_seeds_valid_lift"]))}/{summary["n_seeds_valid_lift"]})')
    lines.append(f'Fraction seeds with placebo_lift > {REAL_LIFT}% (real point): {summary["fraction_lift_gt_real_point"]*100:.1f}% ({int(round(summary["fraction_lift_gt_real_point"]*summary["n_seeds_valid_lift"]))}/{summary["n_seeds_valid_lift"]})')
lines.append('='*68)
with open(OUT_TXT,'w') as f: f.write('\n'.join(lines))
print(); print('\n'.join(lines))
log(f'JSON -> {OUT_JSON}')
log(f'TXT  -> {OUT_TXT}')
