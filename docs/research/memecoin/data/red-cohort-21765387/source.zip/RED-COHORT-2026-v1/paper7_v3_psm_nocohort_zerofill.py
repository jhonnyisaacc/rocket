#!/usr/bin/env python3
"""Paper 7 v3: First-cut PSM analysis for cohort-touched vs matched-control launches.

Reproduces the paper's TREATED set (>=2 cohort wallets in first-10 buyers of a launch,
n_treated ~= 5,411) from the FROZEN buyer corpus
(<data-path>/pumpfun_buyers.jsonl.stale_2026-06-29 = 1,578,333 rows), then
builds a launch-quality propensity score from launch-metadata covariates
(<data-path>/pumpfun_launches.jsonl), matches treated to untouched
controls 1:1 on the propensity, and reports matched-sample buyer-30m / SOL-30m lifts
with bootstrap 95% CIs.

Covariates in the logit propensity model:
  - log1p(initial_market_cap_sol)
  - has_twitter, has_website, has_telegram (binary)
  - log1p(description_length)
  - launch_hour_utc (0-23, treated as categorical via cyclical sin/cos)
  - launch_day_of_corpus (integer day index)

Not included in this cut (documented as limitation):
  - deployer-address novelty (deployer not in launches file schema)
  - wallet-level covariates (funding graph, prior tx history)
"""

import json
import gzip
import math
import os
import sys
from collections import defaultdict

import numpy as np

BUYERS_FILE = "<data-path>/pumpfun_buyers.jsonl.stale_2026-06-29"
LAUNCHES_FILE = "<data-path>/pumpfun_launches.jsonl"
COHORTS_FILE = "<data-path>/sniper_cohorts.jsonl"
INTRA_FILE = "<data-path>/sniper_cohorts_intra.jsonl.gz"

OUT_DIR = "/tmp/paper7_v3_zerofill"
os.makedirs(OUT_DIR, exist_ok=True)

RNG_SEED = 42
BOOTSTRAP_N = 1000
MATCH_RATIO = 1  # 1:1 nearest-neighbor
CALIPER = 0.2   # in units of the propensity-score SD (Rosenbaum & Rubin standard)


def log(msg):
    print(msg, flush=True)


def load_cohort_wallets():
    wallets = set()
    with open(COHORTS_FILE) as f:
        for line in f:
            c = json.loads(line)
            for w in c["wallets"]:
                wallets.add(w)
    return wallets


def build_treated_and_outcomes(cohort_wallets):
    """One pass over frozen buyers file. Returns:
       - per_mint_first10_cohort: dict[mint] -> set of cohort wallets in first-10
       - per_mint_first_bt: dict[mint] -> earliest blockTime observed among first-10
       - per_mint_all_events: dict[mint] -> list of (blockTime, sol_in)
    """
    per_mint_first10_cohort = defaultdict(set)
    per_mint_first_bt = {}
    per_mint_events = defaultdict(list)
    n = 0
    with open(BUYERS_FILE) as f:
        for line in f:
            n += 1
            try:
                r = json.loads(line)
            except Exception:
                continue
            m = r.get("mint")
            if not m:
                continue
            bt = r.get("blockTime")
            sol = r.get("sol_in") or 0.0
            rank = r.get("buyer_rank")
            w = r.get("wallet")
            if bt is not None:
                if w not in cohort_wallets:
                    per_mint_events[m].append((bt, sol))
                if rank is not None and rank <= 10:
                    if m not in per_mint_first_bt or bt < per_mint_first_bt[m]:
                        per_mint_first_bt[m] = bt
                    if w in cohort_wallets:
                        per_mint_first10_cohort[m].add(w)
    log(f"buyer_events_scanned={n} mints_with_any_events={len(per_mint_events)} "
        f"mints_with_first10_coverage={len(per_mint_first_bt)}")
    return per_mint_first10_cohort, per_mint_first_bt, per_mint_events


def compute_30m_outcomes(per_mint_events, per_mint_created_ts):
    """Return dict[mint] -> {'buyers_30m': int, 'sol_30m': float}
    Uses launches-file created_timestamp when available, else earliest buyer blockTime.
    Note created_timestamp is ms since epoch; blockTime is s since epoch.
    """
    out = {}
    for m, events in per_mint_events.items():
        ct_ms = per_mint_created_ts.get(m)
        if ct_ms is not None:
            t0 = ct_ms / 1000.0
        else:
            t0 = min(e[0] for e in events)
        cutoff = t0 + 1800.0  # 30 minutes
        buyers = 0
        sol = 0.0
        for bt, sin in events:
            if bt <= cutoff:
                buyers += 1
                sol += float(sin or 0.0)
        out[m] = {"buyers_30m": buyers, "sol_30m": sol, "t0_s": t0}
    return out


def load_launch_meta():
    """Return dict[mint] -> {covariates}."""
    meta = {}
    with open(LAUNCHES_FILE) as f:
        for line in f:
            try:
                r = json.loads(line)
            except Exception:
                continue
            m = r.get("mint")
            if not m:
                continue
            ct = r.get("created_timestamp")  # ms
            if ct is None:
                ct = r.get("t")  # ms fallback
            if ct is None:
                continue
            meta[m] = {
                "created_timestamp_ms": ct,
                "initial_market_cap_sol": r.get("initial_market_cap_sol") or 0.0,
                "has_twitter": 1 if r.get("has_twitter") else 0,
                "has_website": 1 if r.get("has_website") else 0,
                "has_telegram": 1 if r.get("has_telegram") else 0,
                "description_length": r.get("description_length") or 0,
                "symbol_length": len(r.get("symbol") or ""),
                "name_length": len(r.get("name") or ""),
            }
    return meta


def covariate_matrix(mints, meta, corpus_start_s):
    """Build X matrix (features) for mints. Rows dropped if mint has no meta."""
    keep = []
    rows = []
    for m in mints:
        md = meta.get(m)
        if md is None:
            continue
        ct_s = md["created_timestamp_ms"] / 1000.0
        hour = int((ct_s // 3600) % 24)
        day = int((ct_s - corpus_start_s) // 86400)
        feats = [
            math.log1p(md["initial_market_cap_sol"]),
            md["has_twitter"],
            md["has_website"],
            md["has_telegram"],
            math.log1p(md["description_length"]),
            math.log1p(md["symbol_length"]),
            math.log1p(md["name_length"]),
            math.sin(2 * math.pi * hour / 24.0),
            math.cos(2 * math.pi * hour / 24.0),
            day,
        ]
        keep.append(m)
        rows.append(feats)
    X = np.asarray(rows, dtype=float)
    return keep, X


def fit_logit(X, y, max_iter=200, lr=0.05, l2=1e-3):
    """Simple gradient-descent logit (no scikit dependency).
    Returns weights, bias, standardization stats.
    """
    mu = X.mean(axis=0)
    sd = X.std(axis=0)
    sd[sd == 0] = 1.0
    Xs = (X - mu) / sd
    n, p = Xs.shape
    w = np.zeros(p)
    b = 0.0
    for it in range(max_iter):
        z = Xs @ w + b
        # clip for numerical stability
        z = np.clip(z, -30, 30)
        pr = 1.0 / (1.0 + np.exp(-z))
        grad_w = Xs.T @ (pr - y) / n + l2 * w
        grad_b = float((pr - y).mean())
        w -= lr * grad_w
        b -= lr * grad_b
        if it % 40 == 0:
            loss = float(-(y * np.log(pr + 1e-12) + (1 - y) * np.log(1 - pr + 1e-12)).mean())
            log(f"  logit iter={it} loss={loss:.4f}")
    return w, b, mu, sd


def predict_ps(X, w, b, mu, sd):
    Xs = (X - mu) / sd
    z = np.clip(Xs @ w + b, -30, 30)
    return 1.0 / (1.0 + np.exp(-z))


def nearest_neighbor_match(ps_treated, ps_control, caliper_units=CALIPER):
    """Greedy nearest-neighbor 1:1 match without replacement on propensity SCORE
    (not logit), with a caliper of `caliper_units` * SD(logit(ps)).
    """
    # logit for SD (Rosenbaum-Rubin convention)
    def logit(p):
        p = np.clip(p, 1e-6, 1 - 1e-6)
        return np.log(p / (1 - p))
    lp_t = logit(ps_treated)
    lp_c = logit(ps_control)
    all_lp = np.concatenate([lp_t, lp_c])
    caliper = caliper_units * float(np.std(all_lp))

    # Sort controls by propensity for near-neighbor search
    order = np.argsort(lp_c)
    lp_c_sorted = lp_c[order]
    used = np.zeros(len(lp_c), dtype=bool)

    matches = []  # list of (treated_idx, control_idx, distance)
    # Process treated in random order for fairness
    rng = np.random.default_rng(RNG_SEED)
    t_order = rng.permutation(len(lp_t))
    for ti in t_order:
        target = lp_t[ti]
        # bisect into sorted controls
        pos = int(np.searchsorted(lp_c_sorted, target))
        # scan outward for nearest unused within caliper
        best_j = -1
        best_dist = math.inf
        # walk left and right in sorted order
        l = pos - 1
        r = pos
        # bound scan by caliper; propensities are sorted so we can stop early
        while l >= 0 or r < len(lp_c_sorted):
            if r < len(lp_c_sorted):
                d_r = abs(lp_c_sorted[r] - target)
                if d_r > caliper and (l < 0 or abs(lp_c_sorted[l] - target) > caliper):
                    break
                cj = order[r]
                if not used[cj] and d_r < best_dist:
                    best_dist = d_r
                    best_j = cj
                r += 1
            if l >= 0:
                d_l = abs(lp_c_sorted[l] - target)
                if d_l > caliper and (r >= len(lp_c_sorted) or abs(lp_c_sorted[r] - target) > caliper):
                    break
                cj = order[l]
                if not used[cj] and d_l < best_dist:
                    best_dist = d_l
                    best_j = cj
                l -= 1
            # early exit if we've found a match and neither side can improve
            if best_j != -1:
                left_gap = abs(lp_c_sorted[l] - target) if l >= 0 else math.inf
                right_gap = abs(lp_c_sorted[r] - target) if r < len(lp_c_sorted) else math.inf
                if best_dist <= min(left_gap, right_gap):
                    break
        if best_j != -1 and best_dist <= caliper:
            used[best_j] = True
            matches.append((int(ti), int(best_j), float(best_dist)))
    return matches, caliper


def bootstrap_lift(y_t, y_c, n_iter=BOOTSTRAP_N, seed=RNG_SEED):
    rng = np.random.default_rng(seed)
    n = len(y_t)
    lifts = np.empty(n_iter)
    for i in range(n_iter):
        idx = rng.integers(0, n, n)
        mt = y_t[idx].mean()
        mc = y_c[idx].mean()
        lifts[i] = 100.0 * (mt - mc) / mc if mc > 0 else float("nan")
    valid = lifts[np.isfinite(lifts)]
    return {
        "point_pct": float(np.mean(valid)),
        "ci_low_pct": float(np.percentile(valid, 2.5)),
        "ci_high_pct": float(np.percentile(valid, 97.5)),
        "treated_mean": float(y_t.mean()),
        "control_mean": float(y_c.mean()),
        "n": int(n),
    }


def main():
    log("== Paper 7 v3 first-cut PSM ==")
    log("[1/5] loading cohort wallets")
    cohort_wallets = load_cohort_wallets()
    log(f"  cohort_wallets={len(cohort_wallets)}")

    log("[2/5] scanning frozen buyers file (1.58M events)")
    per_mint_first10, per_mint_first_bt, per_mint_events = build_treated_and_outcomes(cohort_wallets)

    log("[3/5] loading launches metadata")
    meta = load_launch_meta()
    log(f"  launch_meta_rows={len(meta)}")

    # Corpus start = min created_timestamp among launches touched by first-10
    corpus_ts = [
        meta[m]["created_timestamp_ms"] / 1000.0
        for m in per_mint_first_bt
        if m in meta
    ]
    if not corpus_ts:
        log("FATAL: no overlap between buyers and launches")
        sys.exit(1)
    corpus_start_s = min(corpus_ts)
    corpus_end_s = max(corpus_ts)
    log(f"  corpus_span_s: {corpus_start_s} -> {corpus_end_s}  "
        f"({(corpus_end_s-corpus_start_s)/86400:.1f} days)")

    # UNIVERSE = mints with first-10 buyer coverage AND launch meta
    universe = [m for m in per_mint_first_bt if m in meta]
    log(f"  universe (first-10-covered mints with launch meta)={len(universe)}")

    treated_set = {m for m, ws in per_mint_first10.items() if len(ws) >= 2}
    treated_mints = [m for m in universe if m in treated_set]
    control_mints_all = [m for m in universe if m not in treated_set]
    log(f"  treated_mints (>=2 cohort wallets in first-10)={len(treated_mints)}")
    log(f"  control_pool (untouched, first-10-covered)={len(control_mints_all)}")

    # Restrict to corpus window (guard against launches file drift)
    def in_window(m):
        return corpus_start_s <= meta[m]["created_timestamp_ms"] / 1000.0 <= corpus_end_s
    treated_mints = [m for m in treated_mints if in_window(m)]
    control_mints_all = [m for m in control_mints_all if in_window(m)]
    log(f"  after time-window filter: treated={len(treated_mints)} controls={len(control_mints_all)}")

    log("[4/5] building covariate matrices and fitting propensity model")
    m_t, X_t = covariate_matrix(treated_mints, meta, corpus_start_s)
    m_c, X_c = covariate_matrix(control_mints_all, meta, corpus_start_s)
    log(f"  X_t.shape={X_t.shape} X_c.shape={X_c.shape}")

    # Fit logit on combined
    X = np.vstack([X_t, X_c])
    y = np.concatenate([np.ones(len(X_t)), np.zeros(len(X_c))])
    w, b, mu, sd = fit_logit(X, y, max_iter=400, lr=0.1, l2=1e-3)
    log(f"  weights={w.tolist()} bias={b:.4f}")

    ps_t = predict_ps(X_t, w, b, mu, sd)
    ps_c = predict_ps(X_c, w, b, mu, sd)
    log(f"  ps_treated: mean={ps_t.mean():.4f} p50={np.median(ps_t):.4f} "
        f"p05={np.percentile(ps_t,5):.4f} p95={np.percentile(ps_t,95):.4f}")
    log(f"  ps_control: mean={ps_c.mean():.4f} p50={np.median(ps_c):.4f} "
        f"p05={np.percentile(ps_c,5):.4f} p95={np.percentile(ps_c,95):.4f}")

    log("[5/5] nearest-neighbor 1:1 matching without replacement")
    matches, caliper = nearest_neighbor_match(ps_t, ps_c, caliper_units=CALIPER)
    log(f"  matched_pairs={len(matches)}  caliper_logit_ps={caliper:.4f}")

    # Compute outcomes (uses launches created_timestamp as t0)
    per_mint_created_ts = {m: meta[m]["created_timestamp_ms"] for m in universe}
    outcomes = compute_30m_outcomes(per_mint_events, per_mint_created_ts)
    _z = 0
    for _m in universe:
        if _m not in outcomes:
            outcomes[_m] = {"buyers_30m": 0, "sol_30m": 0.0, "t0_s": 0.0}
            _z += 1
    log(f"  zero-filled mints (no non-cohort buyers in window): {_z}")

    # Build matched arrays
    t_buyers, c_buyers = [], []
    t_sol, c_sol = [], []
    for ti, cj, _dist in matches:
        tm = m_t[ti]
        cm = m_c[cj]
        to = outcomes.get(tm)
        co = outcomes.get(cm)
        if to is None or co is None:
            continue
        t_buyers.append(to["buyers_30m"])
        c_buyers.append(co["buyers_30m"])
        t_sol.append(to["sol_30m"])
        c_sol.append(co["sol_30m"])
    t_buyers = np.array(t_buyers, dtype=float)
    c_buyers = np.array(c_buyers, dtype=float)
    t_sol = np.array(t_sol, dtype=float)
    c_sol = np.array(c_sol, dtype=float)
    log(f"  matched-sample buyer_treated_mean={t_buyers.mean():.3f} "
        f"buyer_control_mean={c_buyers.mean():.3f}")
    log(f"  matched-sample sol_treated_mean={t_sol.mean():.3f} "
        f"sol_control_mean={c_sol.mean():.3f}")

    buyer_lift = bootstrap_lift(t_buyers, c_buyers)
    sol_lift = bootstrap_lift(t_sol, c_sol)

    # Also report unmatched (naive) lift on same universe for comparison
    naive_buyers_t = np.array([outcomes[m]["buyers_30m"] for m in m_t if m in outcomes], dtype=float)
    naive_buyers_c = np.array([outcomes[m]["buyers_30m"] for m in m_c if m in outcomes], dtype=float)
    naive_sol_t = np.array([outcomes[m]["sol_30m"] for m in m_t if m in outcomes], dtype=float)
    naive_sol_c = np.array([outcomes[m]["sol_30m"] for m in m_c if m in outcomes], dtype=float)
    # Naive lift = pooled means diff (not bootstrap; just for a rough delta)
    naive_buyer_lift = 100.0 * (naive_buyers_t.mean() - naive_buyers_c.mean()) / naive_buyers_c.mean()
    naive_sol_lift = 100.0 * (naive_sol_t.mean() - naive_sol_c.mean()) / naive_sol_c.mean()

    # Covariate balance check on matched pairs
    def std_diff(a, b):
        # standardized mean difference
        s = math.sqrt((a.var() + b.var()) / 2.0)
        return (a.mean() - b.mean()) / s if s > 0 else 0.0

    balance = {}
    for j, name in enumerate([
        "log1p_initmcap_sol", "has_twitter", "has_website", "has_telegram",
        "log1p_desc_len", "log1p_symbol_len", "log1p_name_len",
        "hour_sin", "hour_cos", "corpus_day",
    ]):
        pre = std_diff(X_t[:, j], X_c[:, j])
        matched_t = X_t[[ti for ti, _cj, _d in matches], j]
        matched_c = X_c[[cj for _ti, cj, _d in matches], j]
        post = std_diff(matched_t, matched_c)
        balance[name] = {"pre_matching_smd": float(pre), "post_matching_smd": float(post)}

    result = {
        "meta": {
            "script": "paper7_v3_psm_nocohort_zerofill.py",
            "buyers_file": BUYERS_FILE,
            "launches_file": LAUNCHES_FILE,
            "cohorts_file": COHORTS_FILE,
            "seed": RNG_SEED,
            "bootstrap_iters": BOOTSTRAP_N,
            "match": "1:1 nearest-neighbor without replacement, logit-PS caliper 0.2 SD",
            "n_cohort_wallets": len(cohort_wallets),
            "corpus_start_s": corpus_start_s,
            "corpus_end_s": corpus_end_s,
            "corpus_days": (corpus_end_s - corpus_start_s) / 86400.0,
            "n_universe_mints": len(universe),
            "n_treated_pre_match": len(m_t),
            "n_control_pool_pre_match": len(m_c),
            "n_matched_pairs": int(len(matches)),
            "caliper_logit_ps": float(caliper),
        },
        "matched_sample_lift": {
            "buyers_30m": buyer_lift,
            "sol_30m": sol_lift,
        },
        "naive_pooled_lift_same_universe": {
            "buyers_30m_pct": float(naive_buyer_lift),
            "sol_30m_pct": float(naive_sol_lift),
            "n_treated": int(len(naive_buyers_t)),
            "n_control_pool": int(len(naive_buyers_c)),
        },
        "covariate_balance": balance,
        "paper_reference_naive_lifts_pct": {
            "buyers_30m": 132.3,
            "sol_30m": 136.5,
        },
        "paper_placebo_activity_matched_pct": {
            "buyers_30m_point": 216.3,
            "buyers_30m_ci": [183.8, 255.2],
        },
    }
    out_path = os.path.join(OUT_DIR, "psm_results.json")
    with open(out_path, "w") as f:
        json.dump(result, f, indent=2)
    log(f"WROTE {out_path}")
    # Also dump summary to stdout
    log(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
